// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCZQDRart8qeVWf0qFIC0NhYTlTWZ-l1XE",
  authDomain: "driver-manager-a242b.firebaseapp.com",
  projectId: "driver-manager-a242b",
  storageBucket: "driver-manager-a242b.firebasestorage.app",
  messagingSenderId: "659404728909",
  appId: "1:659404728909:web:b59a4d54ac8a3a8bb08a04",
  measurementId: "G-4E9TTQ6CDS"
};